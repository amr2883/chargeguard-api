<?php
/**
 * ChargeGuard - Dynamic Firewall
 *
 * يمنع الأجهزة المحظورة من الوصول إلى صفحة الدفع،
 * ويضيف طبقة حماية عبر رمز جلسة آمنة.
 *
 * @package ChargeGuard_WooCommerce
 */

defined('ABSPATH') || exit;

/**
 * ─────────────────────────────────────────────────────────────────────────────
 * WHY WE USE Automattic\WooCommerce\StoreApi\Exceptions\RouteException
 * ─────────────────────────────────────────────────────────────────────────────
 * The WooCommerce Store API (used by Checkout Blocks) does NOT honour:
 *   - wc_add_notice()          → session-based, ignored by the REST response
 *   - throw new \Exception()   → caught internally, not surfaced to the UI
 *   - wp_die()                 → breaks the JSON response contract
 *
 * The ONLY way to:
 *   (a) stop order creation, AND
 *   (b) return a human-readable error to the Block checkout UI
 * is to throw a RouteException. WooCommerce's Store API catches it and
 * converts it into a proper JSON error response that the Blocks JS renders.
 * ─────────────────────────────────────────────────────────────────────────────
 */
use Automattic\WooCommerce\StoreApi\Exceptions\RouteException;

class ChargeGuard_Blocked_Exception extends \Exception {}

class ChargeGuard_Dynamic_Firewall {

    /** @var ChargeGuard_API_Client|null */
    private $api_client;

    /** @var string WordPress option key for the local device blacklist */
    private $blacklist_option = 'chargeguard_device_blacklist';

    /** @var string WooCommerce session key for the CSRF-style token */
    private $session_token_key = 'chargeguard_checkout_token';

    // ─────────────────────────────────────────────────────────────────────────
    // CONSTRUCTOR — Hook Registration
    // ─────────────────────────────────────────────────────────────────────────

    public function __construct() {
        if (!get_option('chargeguard_enable_firewall', 1)) {
            return;
        }

        error_log('[ChargeGuard] Dynamic Firewall initialised');

        if (class_exists('ChargeGuard_API_Client')) {
            $this->api_client = new ChargeGuard_API_Client();
        }

        // ── REST endpoint (used by the JS layer for client-side pre-flight) ──
        add_action('rest_api_init', [$this, 'register_rest_routes']);

        // ── Classic Checkout (shortcode) ─────────────────────────────────────
        add_action('woocommerce_before_checkout_form', [$this, 'inject_session_token']);
        add_action('woocommerce_checkout_process',     [$this, 'validate_session_token']);
        add_action('woocommerce_checkout_process',     [$this, 'intercept_classic_checkout']);

        // ── Checkout Blocks / Store API ───────────────────────────────────────
        //
        // CRITICAL TIMING NOTE:
        // woocommerce_store_api_checkout_order_validation fires BEFORE the order
        // is persisted to the database. It receives the WC_Order object (already
        // populated from the request, but NOT yet saved). Throwing a RouteException
        // here causes the Store API to return a 400 JSON error and roll back —
        // the order is never written to the DB.
        //
        // Priority 10 is fine; WooCommerce's own validators also use priority 10.
        add_action(
            'woocommerce_store_api_checkout_order_validation',
            [$this, 'intercept_blocks_checkout'],
            10,
            1   // receives $order (WC_Order)
        );

        // ── Device fingerprint layer ──────────────────────────────────────────
        add_action('wp_enqueue_scripts',              [$this, 'enqueue_firewall_assets']);
        add_action('wp_enqueue_scripts',              [$this, 'enqueue_checkout_block_js']);
        add_action('woocommerce_before_checkout_form', [$this, 'handle_checkout_access']);

        // ── Ajax fingerprint check ────────────────────────────────────────────
        add_action('wp_ajax_chargeguard_check_fp',        [$this, 'ajax_check_fingerprint']);
        add_action('wp_ajax_nopriv_chargeguard_check_fp', [$this, 'ajax_check_fingerprint']);

        // ── Internal hook: mark a device as fraudulent ────────────────────────
        add_action('chargeguard_mark_device_fraud', [$this, 'add_device_to_blacklist']);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // REST ROUTES
    // ─────────────────────────────────────────────────────────────────────────

    public function register_rest_routes() {
        // Pre-flight endpoint called by the JS layer before the user clicks
        // "Place Order". Returns the risk decision so the client can show an
        // error immediately without waiting for a full checkout POST.
        register_rest_route('chargeguard/v1', '/evaluate', [
            'methods'             => 'POST',
            'callback'            => [$this, 'rest_evaluate_risk'],
            'permission_callback' => '__return_true',
            'args'                => [
                'email'           => ['sanitize_callback' => 'sanitize_email'],
                'amount'          => ['sanitize_callback' => 'floatval'],
                'billing_country' => ['sanitize_callback' => 'sanitize_text_field'],
            ],
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // LAYER 1 — Session Token (CSRF protection for Classic Checkout)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Generate a cryptographic token and embed it as a hidden field.
     * Classic checkout only — Blocks use nonce-protected REST calls.
     */
    public function inject_session_token() {
        if (!WC()->session) {
            return;
        }
        $token = bin2hex(random_bytes(32));
        WC()->session->set($this->session_token_key, $token);
        echo '<input type="hidden" name="chargeguard_session_token" value="' . esc_attr($token) . '" />';
    }

    /**
     * Reject the classic checkout if the token is missing or tampered.
     */
    public function validate_session_token() {
        if (!WC()->session) {
            return;
        }
        $submitted = sanitize_text_field(wp_unslash($_POST['chargeguard_session_token'] ?? ''));
        $stored    = WC()->session->get($this->session_token_key);

        if (empty($stored) || empty($submitted) || !hash_equals($stored, $submitted)) {
            wc_add_notice(
                __('Security verification failed. Please refresh the page and try again.', 'chargeguard-woocommerce'),
                'error'
            );
            WC()->session->__unset($this->session_token_key);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // LAYER 2 — Device Fingerprint Blacklist
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Enqueue the fingerprinting + firewall JS on the checkout page only.
     */
    public function enqueue_firewall_assets() {
        if (!is_checkout()) {
            return;
        }
        wp_enqueue_script(
            'chargeguard-firewall',
            plugin_dir_url(__FILE__) . '../assets/js/chargeguard-firewall.js',
            ['jquery'],
            CHARGEGUARD_VERSION,
            true
        );
        wp_localize_script('chargeguard-firewall', 'chargeguard_fw', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('chargeguard_fw_nonce'),
        ]);
    }

    /**
     * Gate keeper called before the classic checkout form renders.
     * Throws a WP_Die if the device is blacklisted.
     */
    public function handle_checkout_access() {
        try {
            $this->check_device_blacklist();
        } catch (ChargeGuard_Blocked_Exception $e) {
            wp_die(
                esc_html($e->getMessage()),
                esc_html__('Access Restricted', 'chargeguard-woocommerce'),
                ['response' => 403]
            );
        }
    }

    /**
     * Check the cookie-based fingerprint against the local blacklist and,
     * optionally, the remote API.
     *
     * @throws ChargeGuard_Blocked_Exception
     */
    public function check_device_blacklist() {
        if (empty($_COOKIE['chargeguard_fp'])) {
            return;
        }
        $fingerprint = sanitize_text_field(wp_unslash($_COOKIE['chargeguard_fp']));

        // Local blacklist — with automatic expiry cleanup
        $local_blacklist = get_option($this->blacklist_option, []);
        if (is_array($local_blacklist)) {
            $now = time();
            $dirty = false;
            foreach ($local_blacklist as $fp => $expires) {
                if ($expires < $now) {
                    unset($local_blacklist[$fp]);
                    $dirty = true;
                }
            }
            if ($dirty) {
                update_option($this->blacklist_option, $local_blacklist);
            }
            if (isset($local_blacklist[$fingerprint]) && $local_blacklist[$fingerprint] > $now) {
                $this->block_access();
            }
        }

        // Remote API check (optional — only when API key is configured)
        if ($this->api_client && $this->api_client->get_api_key()) {
            $response = $this->api_client->check_device($fingerprint);
            if (!is_wp_error($response) && !empty($response['blocked'])) {
                $this->add_device_to_blacklist($fingerprint);
                $this->block_access();
            }
        }
    }

    /**
     * Persist a fingerprint in the local blacklist with a configurable TTL.
     *
     * @param string $fingerprint
     */
    public function add_device_to_blacklist($fingerprint) {
        if (empty($fingerprint)) {
            return;
        }
        $blacklist      = get_option($this->blacklist_option, []);
        $duration_hours = (int) get_option('chargeguard_firewall_block_duration', 24);
        $blacklist[$fingerprint] = time() + ($duration_hours * 3600);
        update_option($this->blacklist_option, $blacklist);
    }

    /** @throws ChargeGuard_Blocked_Exception */
    private function block_access() {
        throw new ChargeGuard_Blocked_Exception(
            esc_html__('Sorry, we cannot process your order at this time. Please contact support.', 'chargeguard-woocommerce')
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // LAYER 3 — Ajax Fingerprint Check (called from chargeguard-firewall.js)
    // ─────────────────────────────────────────────────────────────────────────

    public function ajax_check_fingerprint() {
        check_ajax_referer('chargeguard_fw_nonce', 'nonce');

        $fingerprint = sanitize_text_field(wp_unslash($_POST['fingerprint'] ?? ''));
        $blocked     = false;

        $blacklist = get_option($this->blacklist_option, []);
        if (is_array($blacklist) && isset($blacklist[$fingerprint]) && $blacklist[$fingerprint] > time()) {
            $blocked = true;
        }

        if (!$blocked && $this->api_client && $this->api_client->get_api_key()) {
            $response = $this->api_client->check_device($fingerprint);
            if (!is_wp_error($response) && !empty($response['blocked'])) {
                $blocked = true;
                $this->add_device_to_blacklist($fingerprint);
            }
        }

        wp_send_json_success(['blocked' => $blocked]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // LAYER 4A — Classic Checkout Risk Evaluation
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Called during woocommerce_checkout_process (classic shortcode only).
     * Uses wc_add_notice + Exception to stop the order.
     */
    public function intercept_classic_checkout() {
        if (!$this->api_client || !$this->api_client->get_api_key()) {
            return;
        }

        $order_data = [
            'orderId'           => 'pre_' . uniqid(),
            'email'             => sanitize_email($_POST['billing_email'] ?? ''),
            'ipAddress'         => $this->get_client_ip(),
            'deviceFingerprint' => sanitize_text_field($_COOKIE['chargeguard_fp'] ?? ''),
            'amount'            => (float) (WC()->cart ? WC()->cart->total : 0),
            'billingCountry'    => sanitize_text_field($_POST['billing_country'] ?? ''),
            'shippingCountry'   => sanitize_text_field($_POST['shipping_country'] ?? ''),
            'merchantId'        => get_option('chargeguard_merchant_id', ''),
        ];

        $result = $this->api_client->evaluate_risk($order_data);

        if (is_wp_error($result)) {
            error_log('[ChargeGuard] Classic checkout API error: ' . $result->get_error_message());
            return; // Fail open — never block on API errors
        }

        error_log('[ChargeGuard] Classic checkout decision: ' . ($result['decision'] ?? 'none'));

        if (($result['decision'] ?? '') === 'block') {
            $message = __('Sorry, we cannot process your order at this time. Please try again later or contact support.', 'chargeguard-woocommerce');
            wc_add_notice($message, 'error');
            throw new \Exception($message);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // LAYER 4B — Checkout Blocks / Store API Risk Evaluation
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Called by woocommerce_store_api_checkout_order_validation.
     *
     * ── WHY THIS WORKS ───────────────────────────────────────────────────────
     * This action fires inside the Store API route handler AFTER the order
     * object is assembled from the cart/request but BEFORE
     * AbstractOrderController::update_order_from_cart() flushes it to the DB.
     *
     * Throwing a RouteException here causes WooCommerce to:
     *   1. Abort the save
     *   2. Return a structured JSON error (HTTP 422) to the Blocks JS
     *   3. Display the message inside the Block checkout UI automatically
     *
     * ── WHY NOT throw new \Exception() ───────────────────────────────────────
     * A plain Exception is caught by the Store API and re-thrown as a generic
     * "checkout error" without your custom message. RouteException is the
     * documented contract for validation failures in Store API routes.
     *
     * ── HOW TO CONFIRM IT FIRES ───────────────────────────────────────────────
     * Add: error_log('[ChargeGuard] intercept_blocks_checkout CALLED');
     * Then place a test order via the Block checkout. If you don't see the log,
     * check that:
     *   - WooCommerce ≥ 8.3 (hook was introduced in 7.2 but stabilised in 8.x)
     *   - The Store API is actually handling the request (Network tab → POST to
     *     /wp-json/wc/store/v1/checkout)
     *   - No other plugin has removed the action before this class initialises
     *
     * @param \WC_Order $order The in-memory order (not yet saved).
     * @throws RouteException  Stops order creation and surfaces the message.
     */
    public function intercept_blocks_checkout(\WC_Order $order) {
        error_log('[ChargeGuard] intercept_blocks_checkout CALLED — order total: ' . $order->get_total());

        if (!$this->api_client || !$this->api_client->get_api_key()) {
            error_log('[ChargeGuard] No API client or key — skipping blocks check');
            return;
        }

        $order_data = [
            'orderId'           => 'pre_' . uniqid(),
            'email'             => $order->get_billing_email(),
            'ipAddress'         => $this->get_client_ip(),
            'deviceFingerprint' => sanitize_text_field($_COOKIE['chargeguard_fp'] ?? ''),
            'amount'            => (float) $order->get_total(),
            'billingCountry'    => $order->get_billing_country(),
            'shippingCountry'   => $order->get_shipping_country(),
            'merchantId'        => get_option('chargeguard_merchant_id', ''),
        ];

        $result = $this->api_client->evaluate_risk($order_data);

        if (is_wp_error($result)) {
            error_log('[ChargeGuard] Blocks checkout API error: ' . $result->get_error_message());
            return; // Fail open
        }

        $decision = $result['decision'] ?? '';
        error_log('[ChargeGuard] Blocks checkout decision: ' . $decision);

        if ($decision === 'block') {
            error_log('[ChargeGuard] Blocking order via RouteException');

            // RouteException signature: (string $error_code, string $message, int $http_status)
            // HTTP 422 Unprocessable Entity is the correct status for validation failures.
            throw new RouteException(
                'chargeguard_order_blocked',
                __('Sorry, we cannot process your order at this time. Please try again later or contact support.', 'chargeguard-woocommerce'),
                422
            );
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // LAYER 5 — REST Pre-flight (called by chargeguard-checkout-block.js)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * JavaScript calls this endpoint to get a risk decision BEFORE the user
     * clicks "Place Order". If the decision is "block" the JS can show an
     * inline error without ever hitting the Store API — faster UX and one
     * fewer orphaned order record to clean up.
     *
     * Server-side validation (intercept_blocks_checkout) is ALWAYS the
     * authoritative gate. This endpoint is defence-in-depth only.
     */
    public function rest_evaluate_risk(\WP_REST_Request $request) {
        if (!$this->api_client) {
            return new \WP_Error('no_api_client', 'API client not available', ['status' => 500]);
        }

        $order_data = [
            'orderId'        => 'pre_' . uniqid(),
            'email'          => $request->get_param('email'),
            'ipAddress'      => $this->get_client_ip(),
            'amount'         => (float) $request->get_param('amount'),
            'billingCountry' => $request->get_param('billing_country'),
            'merchantId'     => get_option('chargeguard_merchant_id', ''),
        ];

        $result = $this->api_client->evaluate_risk($order_data);

        if (is_wp_error($result)) {
            return $result;
        }

        return rest_ensure_response($result);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // LAYER 6 — Checkout Block JS (client-side pre-flight)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Enqueue the Block checkout interceptor script.
     *
     * Dependencies include:
     *   - wc-blocks-checkout : guarantees Blocks runtime is loaded
     *   - wc-store-notice    : needed for the notice store
     *   - wp-data            : wp.data
     *   - wp-element         : wp.element (React hooks used internally)
     */
    public function enqueue_checkout_block_js() {
        if (!is_checkout()) {
            return;
        }

        // Only load when the Blocks checkout is actually present on the page.
        // has_block() parses the post content without a DB query.
        if (
            function_exists('has_block') &&
            !has_block('woocommerce/checkout') &&
            !has_block('woocommerce/classic-shortcode')
        ) {
            return;
        }

        wp_enqueue_script(
            'chargeguard-checkout-block',
            plugin_dir_url(__FILE__) . '../assets/js/chargeguard-checkout-block.js',
            ['jquery', 'wp-data', 'wp-element', 'wc-blocks-checkout'],
            CHARGEGUARD_VERSION,
            true
        );

        wp_localize_script('chargeguard-checkout-block', 'chargeguard_block', [
            'evaluate_url' => rest_url('chargeguard/v1/evaluate'),
            'rest_nonce'   => wp_create_nonce('wp_rest'),
            'messages'     => [
                'blocked' => __('Sorry, we cannot process your order at this time. Please try again later or contact support.', 'chargeguard-woocommerce'),
                'api_error' => __('An error occurred during checkout validation. Please try again.', 'chargeguard-woocommerce'),
            ],
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Get the real client IP, respecting common proxy headers.
     * Restrict to trusted proxies in production if needed.
     *
     * @return string
     */
    private function get_client_ip() {
        $headers = [
            'HTTP_CF_CONNECTING_IP', // Cloudflare
            'HTTP_X_REAL_IP',
            'HTTP_X_FORWARDED_FOR',
            'REMOTE_ADDR',
        ];
        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                // X-Forwarded-For can be a comma-separated list; take the first
                $ip = explode(',', $_SERVER[$header])[0];
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        return '';
    }
}