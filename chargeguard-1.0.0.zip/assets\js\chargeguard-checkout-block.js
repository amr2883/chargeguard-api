/**
 * ChargeGuard - Checkout Block Interceptor
 * 
 * يعترض زر "Place Order" في WooCommerce Checkout Blocks
 * ويستدعي ChargeGuard API قبل السماح بإكمال الطلب.
 * إذا كان القرار "block"، يتم منع الطلب وعرض رسالة خطأ.
 * 
 * @package ChargeGuard_WooCommerce
 */
(function() {
    'use strict';

    // انتظر حتى تحميل jQuery و WooCommerce Blocks
    var attempts = 0;
    var maxAttempts = 50;

    function initChargeGuard() {
        attempts++;

        // تحقق من وجود wp.data و wc.storeApi
        if (typeof wp === 'undefined' || typeof wp.data === 'undefined') {
            if (attempts < maxAttempts) {
                setTimeout(initChargeGuard, 200);
            }
            return;
        }

        // استمع إلى حدث التحقق قبل معالجة الطلب
        wp.data.subscribe(function() {
            var checkoutStore = wp.data.select('wc/store/checkout');
            if (!checkoutStore) return;

            var isBeforeProcessing = checkoutStore.isBeforeProcessing();

            if (isBeforeProcessing) {
                // منع الإرسال مؤقتاً
                var email = checkoutStore.getBillingData().email;
                var amount = checkoutStore.getCartTotals().total_price;
                var billingCountry = checkoutStore.getBillingData().country;

                // تحقق من وجود إيميل
                if (!email) return;

                // استدعاء ChargeGuard API
                fetch(chargeguard_block.evaluate_url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': chargeguard_block.nonce
                    },
                    body: JSON.stringify({
                        email: email,
                        amount: amount / 100, // تحويل من سنتات إلى دولارات
                        billing_country: billingCountry
                    })
                })
                .then(function(response) {
                    return response.json();
                })
                .then(function(data) {
                    if (data.decision === 'block') {
                        // إضافة خطأ لمنع إكمال الطلب
                        wp.data.dispatch('wc/store/checkout').setHasError(true);
                        wp.data.dispatch('wc/store/checkout').__internalSetAfterProcessing({
                            orderStatus: 'failed',
                            paymentDetails: {}
                        });

                        // عرض رسالة خطأ للمستخدم
                        wp.data.dispatch('wc/store/validation').setValidationErrors({
                            'chargeguard': {
                                message: 'Sorry, we cannot process your order. Please try a different payment method or contact support.',
                                hidden: false
                            }
                        });
                    }
                })
                .catch(function(error) {
                    // في حالة فشل الاتصال، نترك الطلب يمر
                    console.error('ChargeGuard Block API error:', error);
                });
            }
        });
    }

    // ابدأ المحاولة بعد تحميل الصفحة
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(initChargeGuard, 500);
        });
    } else {
        setTimeout(initChargeGuard, 500);
    }
})();